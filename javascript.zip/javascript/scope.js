


let//block
const//block scope

if()
{ 
    const a="yash";
    let b="yash";
    console.log(a);//block scope
    var c="yash";//
}
console.log(a);
console.log(c);


//local scope or function scope
function a()
{
    let c="yash";//
}
console(c);//not accessible

