import java.io.FileOutputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
    public static void main(String[] args)
	{
	try
	{
	FileOutputStream fout=new FileOutputStream("poornima.txt");
	BufferedOutputStream binput=new BufferedOutputStream(fin);
	int i;
	while((i=binput.read())!=-1)
	{
	    System.out.print((char)i);
	}
	binput.close();
	fin.close();
	}
	catch(Exception e)
	{
	    e.printStackTrace();
		}
	}
}	