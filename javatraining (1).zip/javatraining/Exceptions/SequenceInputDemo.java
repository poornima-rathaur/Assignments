import java.io.*;
class SequenceInputDemo
{
    public static void main(String[] args) throws Exception
	{
	FileInputStrteam f1=new FileInputStream("abc.txt");
	FileInputStrteam f2=new FileInputStream("xyz.txt");
	Sequence InputStream st=new SequenceInputStream(f1,f2);
	int i;
	while((i=st.read())!=-1)
	{
	    System.out.print((char)i);
		{
		    System.oot.print((char)i);
			}
		st.close();
		f1.close();
		f2.close();
		}
	}