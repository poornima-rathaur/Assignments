class FirstQuestionTwoNo
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
   double b=Double.parseDouble(args[1]);
   
   if(a>b)
	   System.out.println("a is grater");
   else if(a<b)
	   System.out.println("b is greater");
  
   }
   }