class ThirdQuestion
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
 
   
   if (a % 400 == 0)
       System.out.println("yes");
 
    
    if (a % 100 == 0)
       System.out.println("no");
 
   
    if (a % 4 == 0)
       System.out.println("yes");
    
	 System.out.println("no");
   }
   }