class SixthQuestion
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
   double b=Double.parseDouble(args[0]);
   double c;
   a=a^b;
   a=a^b;
   b=a^b;
   System.out.print(a);
   System.out.print(b);
  
  
   }
   }