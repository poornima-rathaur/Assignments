class SecondQuestion
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
 
   
   if(a%2==0)
	   System.out.println("even");
   
   else
       System.out.println("odd");
  
   }
   }