class FirstQuestionThreeNo
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
   double b=Double.parseDouble(args[0]);
   double c=Double.parseDouble(args[0]);
   
   if(a>b && a>c)
	   System.out.println("a is grater");
   else if(b>a && b>c)
	   System.out.println("b is greater");
   else
       System.out.println("c is greater");
  
   }
   }