class StringDemo{
    public static void main(String[] args)
	{
	    String s=new String(" Welcome to Yash Technologies ");
		String str1=new String("Yash Technologies");
		String str2=new String("Yash Technologies");
		String str3=new String("yash technologies");
		
		
		
		System.out.println(s.isEmpty());//1
		
		System.out.println(s.trim());//2
		
		System.out.println(s.equals(str1));//3
		System.out.println(str1.equals(str2));
		System.out.println(s.equals(str1));
		System.out.println(str1.equals(str2));
		
		System.out.println(str1.equalsIgnoreCase(str2));//4
		System.out.println(str2.equalsIgnoreCase(str3));
		
		System.out.println(str1.compareTo(str2));//5
		System.out.println(str2.compareTo(str3));
		
		System.out.println(str1.compareToIgnoreCase(str2));//6
		System.out.println(str2.compareToIgnoreCase(str3));//6
		
		System.out.println(s.substring(0,8));//7
		
		
		
		
		}
		}
		