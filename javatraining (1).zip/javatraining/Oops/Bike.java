abstract class Vehicle
{   //50% abstraction
    abstract void start();
	void show(){
	System.out.println("In Abstract class");
	}
}
class Car extends Vehicle
{
	void start()
	{
		System.out.println("Starts by Kry/Button");
	}
}

class Bike extends Vehicle
{
	void start()
	{
		System.out.println("Start with Kick");
	}
	public static void main(String[] args)
	{
		//Vehicle v=new Vehicle();
		Car c=new Car();
		c.start();
		Bike b=new Bike();
		b.start();
		b.show();
	}
}