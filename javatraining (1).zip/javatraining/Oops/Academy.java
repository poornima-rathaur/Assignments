class Agent
{
private int agent_id;
public void setagent_id(int agent_id)
{
this.agent_id=agent_id;
}
public int getagent_id(){
return agent_id;
}
}
class Academy{
public static void main(String[] args){
Agent p=new Agent();
p.setagent_id(10);
System.out.println(p.getagent_id);
}
}
 