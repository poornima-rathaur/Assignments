class Parent {
   String parenthobby;
   Parent(String n1){
      parenthobby = n1;
   }
   public void display() {
      System.out.println("parenthobby");
   }
}
class Child extends Parent {
   String childhobby;
   Child(String n2) {
      super(n2);
      childhobby = n2;
   }
   public void display() {
      System.out.println("childhobby");
   }
}
public class Test {
   public static void main(String args[]) {
      Child c1 = new Child("playing");
      Parent p1 = new Parent("reading");
      p1 = c1;
      p1.display();

      Parent p2 = new Parent("learning");
      Child c2 = (Child)p2;
   }
}
