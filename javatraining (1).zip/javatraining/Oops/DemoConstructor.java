class DemoConstructor{
 
    int id;  
    String name;  
     
    DemoConstructor(int i,String n){  
    this.name=n; 
    this.id=id;
	System.out.println(name+" "+id);
	}
	 
     public DemoConstructor()
	 {
		 System.out.println("Default Constyructor");
	 }
    
   
    public static void main(String args[]){  
    
    DemoConstructor d1 = new DemoConstructor();  
    DemoConstructor d2 = new DemoConstructor(1010,"Yash");
    
      
   }  
 
}
