
class BoxDimension {
    
    int width;
    int height;
	int result;
  
    BoxDimension(int width, int height)
    {   
	    int result;
        this.width = width;
        this.height = height;
		
    }
	
}
  

class Question1_BoxDimension {
    
    public static void main(String[] args)
    {
        
        BoxDimension bd = new BoxDimension(3, 5);
        System.out.println("Volume of the box" + bd.width*bd.height);
                          
    }
}