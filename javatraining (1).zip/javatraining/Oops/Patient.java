class Double_compute_BMI{
    
    String name;
    double height;
	double weight;
 
  
    Double_compute_BMI(String name, int height, int weight)
    {   
	    
		this.name = name;
        this.weight = weight;
        this.height = height;
		
    }
	
}
  

class Patient{
    
    public static void main(String[] args)
    {
        
        Double_compute_BMI p1 = new Double_compute_BMI("poornima",6,60);
        System.out.println(p1.name+"="+p1.weight/p1.height*p1.height);
                          
    }
}