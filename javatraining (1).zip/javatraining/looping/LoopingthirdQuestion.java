class LoopingthirdQuestion
{
 public static void main(String[] args)
 {
   double number=Double.parseDouble(args[0]);
   int i,fact=1;  
     
  fact = factorial(number);   
  System.out.println("Factorial of "+number+" is: "+fact);   
  
   }
   
  static int factorial(int n){    
  if (n == 0)    
    return 1;    
  else    
    return(n * factorial(n-1));    
 }    
 
}