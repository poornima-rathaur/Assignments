import java.util.Scanner;
class Palindrome{
    public static void main(String[] args)
	{
	Scanner scan= new Scanner(System.in);
	String str1= scan.nextLine();
	char arr1[]=str1.toCharArray(); // without using reverse function
	char arr2[]=new char[arr1.length];
	int j=arr2.length-1;
	for(int i=0;i<=arr1.length-1;i++)
	{
		arr2[j]=arr1[i];
		j--;
	}
	String str2=new String(arr2);
	if(str1.equals(str2))
	    System.out.println("yes string is Palindrome");
	else
	    System.out.println("no, string is not Palindrome");
	
	}
	}