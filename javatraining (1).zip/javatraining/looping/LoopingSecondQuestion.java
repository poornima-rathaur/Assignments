class LoopingSecondQuestion
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
   int fact=1;
   for(int i=1; i<=a; i++){
   fact=fact*i;
  
   }
   System.out.println(fact);
   
 }
}