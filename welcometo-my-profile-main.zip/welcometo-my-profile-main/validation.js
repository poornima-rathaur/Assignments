function welcome(){
    var username=document.getElementById("username").value;
    var welcomeF = "Welcome " +username ;
    alert(welcomeF);


}