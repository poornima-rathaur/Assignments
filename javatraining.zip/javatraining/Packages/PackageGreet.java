import mypackage1.Greet;
class PackageGreet
{
 public static void main(String[] args)
 {
 //mypackage1.Greet ob=new mypackage1.Greet();
 Greet ob=new Greet();
 ob.display();
 }
 }