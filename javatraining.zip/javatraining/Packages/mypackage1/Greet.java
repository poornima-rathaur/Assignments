package mypackage1;
public class Greet
{
    public void display()
	{
	System.out.println("Hello there!");
	}
}