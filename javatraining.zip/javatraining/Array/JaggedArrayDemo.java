class JaggedArrayDemo
{
 public static void main(String[] args)
 {
   int[] a=new {10,20,30,40,50,60);
   int sum=0;
   int count=0;
   for(int i=0;i<a.length;i++){
	   sum=sum+a[i];
	   count=count+1;
   }
  
   System.out.println(sum);
   System.out.println(sum/count);
   //System.out.println(a[0][0]);
  // System.out.println(a.length);
  // System.out.println(a[0][0].length);
   
   }
   }