class ArrayReverse
{
	public static void main(String [] args)
	{
		int num1=Integer.parseInt(args[0]);
		int num2=Integer.parseInt(args[1]);
		int num3=Integer.parseInt(args[2]);
		int num4=Integer.parseInt(args[3]);
		
		int[][] arr=new int[][]{{num4,num3},{num2,num1}};
		System.out.print(arr[0][0]+" "+arr[0][1]+" "+arr[1][0]+" "+arr[1][1]);
	}
}