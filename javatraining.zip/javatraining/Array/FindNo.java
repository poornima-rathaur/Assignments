class FindNo
{
 public static void main(String[] args)
 {
   int[] arr={10,20,30,40,50,60};
   int n=20;
   int flag=0;
   for(int i=0;i<arr.length;i++){
    if(arr[i]==n)
	{
	System.out.println(i);
	flag=1;
   }
}
if(flag==0)
    System.out.println(-1);
	}

}