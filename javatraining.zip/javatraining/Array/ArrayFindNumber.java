class ArrayFindNumber
{
	public static void main(String [] args)
	{
		int num=Integer.parseInt(args[0]);
		int[] arr=new int[]{10,20,30,40,50,60};
		for(int a=0;a<arr.length;a++)
		{
			if(num==arr[a])
			{
				System.out.println(a);
				break;
			}
			if(arr.length-1==a)
				System.out.println("-1");
		}		
	}
}