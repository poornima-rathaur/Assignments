class SumAndAvg
{
 public static void main(String[] args)
 {
   int[] a={10,20,30,40,50,60};
   int sum=0;
   int count=0;
   
   for(int i=0;i<a.length;i++)
   {
	   sum=sum+a[i];
	   count=count+1;
   }
  
   System.out.println(sum);
   System.out.println(sum/count);
 
   }

}