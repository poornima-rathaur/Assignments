class FourthQuestion
{
 public static void main(String[] args)
 {
   int num1=Integer.parseInt(args[0]);
   int num2=Integer.parseInt(args[0]);
   
    System.out.print("Enter an number 1.addition 2.subtraction 3.Multiplication 4. Division ");
     int operator=Integer.parseInt(args[0]);   
       // scanner.close();
        
   
        switch(operator)
        {
            case '1':
            	System.out.print( num1 + num2);
                break;

            case '2':
            	System.out.print(num1 - num2);
                break;

            case '3':
            	System.out.print(num1 * num2);
                break;

            case '4':
            	System.out.print(num1 / num2);
                break;

           
            default:
                System.out.printf("You have entered wrong operator");
                
        }
		
	}
}






    
   
