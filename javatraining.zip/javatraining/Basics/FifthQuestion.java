class FifthQuestion
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
   double b=Double.parseDouble(args[0]);
   double c;
   c=a;
   b=a;
   a=c;
   System.out.print(a);
   System.out.print(b);
  
  
   }
   }