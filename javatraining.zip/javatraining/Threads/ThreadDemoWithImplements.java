class ThreadDemoWithImplements implements Runnable
{
	public void run()
	{
		System.out.println("Thread is Working Now!");
	}
	public static void main(String [] args)
	{
		ThreadDemoWithImplements td=new ThreadDemoWithImplements();
		Thread t=new Thread(td);
		t.start();
	}
}