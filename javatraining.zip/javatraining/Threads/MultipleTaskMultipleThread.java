class Demo1 extends Thread
{
	public void run()
	{
		System.out.println("I am in Demo1");
	}
}
class Demo2 extends Thread
{
	public void run()
	{
		System.out.println("I am in Demo2");
	}
}
class Demo3 extends Thread
{
	public void run()
	{
		System.out.println("I am in Demo3");
	}
}

class MultipleTaskMultipleThread
{
	public static void main(String [] args)
	{
		Demo1 t=new Demo1();
		t.start();
		Demo2 t2=new Demo2();
		t2.start();
		Demo3 t3=new Demo3();
		t3.start();
	}
}