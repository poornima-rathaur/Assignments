class Animal{
    void eat()
	{
	System.out.println("I am eating");
	}
	
	public static void main(String[] args){
	    Animal lion=new Animal();
		lion.eat();
		}
    }  
