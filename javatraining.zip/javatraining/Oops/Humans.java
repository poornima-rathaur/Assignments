class Apes{  //Singl level Inheritance
void display(){
System.out.println("Eat");
}
}

class Humans extends Apes
{
void display(){
System.out.println("Work");
}

public static void main(String[] args){
Apes obj=new Apes();
obj.displayHumans();
}

}
 
 