//Question 1 Inheritance
class Animal
{
 void eat()
 {
  System.out.println("Animal is eating");
 }
 void sleep()
 {
  System.out.println("Animal is sleeping");
 }
}

class Bird extends Animal
{
 void eat()
 {
 System.out.println("Animal is eating");
 }
 void sleep()
 {
  System.out.println("Animal is sleeping");
 }
 void fly()
 {
  System.out.println("Birds are Flying");
 }
 
public static void main(String[] args)
{
Animal lion= new Animal();
lion.eat();
lion.sleep();

Bird pica=new Bird();
pica.eat();
pica.sleep();

Bird huming=new Bird();
huming.eat();
huming.sleep();
huming.fly();

}
}