class Person
{
	private String name;
	private String dob;
	
	void setName(String name)
	{
		this.name=name;
	}
	
	String getName()
	{
		return name;
	}
	
	void setDob(String dob)
	{
		this.dob=dob;
	}
	
	String getDob()
	{
		return dob;
	}
}

class Teacher extends Person
{
	private int salary;
	private String subject;
	
	void setSalary(int salary)
	{
		this.salary=salary;
	}
	
	int getSalary()
	{
		return salary;
	}
	
	void setSubject(String subject)
	{
		this.subject=subject;
	}
	
	String getSubject()
	{
		return subject;
	}
}

class Student extends Person
{
	int studentId;
	
	void setStudentId(int studentId)
	{
		this.studentId=studentId;
	}
	
	int getStudentId()
	{
		return studentId;
	}
}

class CollegeStudent extends Student
{
	String collegeName;
	int year;
	
	void setCollegeName(String collegeName)
	{
		this.collegeName=collegeName;
	}
	
	String getCollegeName()
	{
		return collegeName;
	}
	
	void setYear(int year)
	{
		this.year=year;
	}
	
	int getYear()
	{
		return year;
	}
}

class Inheritance2
{
	public static void main(String [] args)
	{
		CollegeStudent student=new CollegeStudent();
		student.setName("Hritik");
		student.setDob("01-01-2000");
		student.setStudentId(101);
		student.setCollegeName("IET-DAVV");
		student.setYear(4);
		
		System.out.println("Student Name: "+student.getName());
		System.out.println("Student Dob: "+student.getDob());
		System.out.println("Student ID: "+student.getStudentId());
		System.out.println("College Name: "+student.getCollegeName());
		System.out.println("College Year: "+student.getYear()+" Year");
		
		Teacher teacher=new Teacher();
		teacher.setName("Jaynam Sir");
		teacher.setDob("02-02-1990");
		teacher.setSalary(80000);
		teacher.setSubject("Java Full Stack Development");
		
		System.out.println("\n");
		System.out.println("Teacher Name: "+teacher.getName());
		System.out.println("Teacher Dob: "+teacher.getDob());
		System.out.println("Teacher Salary: "+teacher.getSalary());
		System.out.println("Teacher Subject: "+teacher.getSubject());
	}
}