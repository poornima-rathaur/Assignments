class ClassCastException
{
	public static void main(String [] args)
	{
		String s="Yash";
		int a=(int)s;
	}
}