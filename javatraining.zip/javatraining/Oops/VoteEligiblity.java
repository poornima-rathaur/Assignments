import java.util.Scanner;
class VoteEligiblity extends RuntimeException
{
    VoteEligiblity(String s)
	{
	    super(s);
		}
	}

class ThrowDemo
{
    public static void main(String[] args)
{
    Scanner s=new Scanner(System.in);
    System.out.println("Enter your age");
	int age=s.nextInt();
	try{
	if(age<18)
	{
	    throw new VoteEligibility("You are not eligible for Voting");
		//System.out.println("after throw");
		}
	else
	{
	System.out.println("You can Vote");
	}
	}
	
	catch(VoteEligibility e)
	{
	    e.printStackTrace();
	
		System.out.println("Normal Termination");
		}
		}
