import java.util.Scanner;
class Alternatemerging{
    public static void main(String[] args)
	{
	Scanner scan= new Scanner(System.in);
	String str1= scan.nextLine();
	String str2= scan.nextLine();
	
	StringBuilder result = new StringBuilder();
	 for (int i = 0; i < str1.length() || i < str2.length(); i++) {
  
            if (i < str1.length())
                result.append(str1.charAt(i));
 
           
            if (i < str2.length())
                result.append(str2.charAt(i));
        }
 
         result.toString();
	
	String str3=result.toString();
	System.out.println(str3);
	
	
	
	}
	}