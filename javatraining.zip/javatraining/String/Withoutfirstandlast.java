import java.util.Scanner;
class Withoutfirstandlast{
    public static void main(String[] args)
	{
	Scanner scan= new Scanner(System.in);
	String str1= scan.nextLine();
	char arr1[]=str1.toCharArray(); 
	char arr2[]=new char[arr1.length];
	int n= arr1.length;
	int j=0;
	
	for(int i=1;i<arr1.length-1;i++)
	{
		arr2[j]=arr1[i];
		j++;
	}
	String str2=new String(arr2);
	System.out.println(str2);
	
	
	
	}
	}