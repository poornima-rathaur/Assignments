class StringBuilderDemo{
    public static void main(String[] args)
	{
	    StringBuilder s=new StringBuilder(" Yash Technologies ");
		
		
		//s.concat("Technologies");
		System.out.println(s);//1
		
		s.append("Hello");
		System.out.println(s);//2
		
		System.out.println(s.length());
		System.out.println(s.capacity());
		System.out.println(s.delete(0,6));
		
		
		
		
		}
		}
		