import java.util.*;

class InvalidCountryException extends RuntimeException
{
	InvalidCountryException(String s)
	{
		super(s);
	}
}

class ProfileRegistration
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		String name;
		String country;
		try
		{
			System.out.println("Enter the name: ");
			name=sc.nextLine();
			System.out.println("Enter the country: ");
			country=sc.nextLine();
			
			if(country.equals("India"))
			{
				System.out.println("User registration done successfully.");
			}
			else
			{
				throw new InvalidCountryException("User outside India cannot be registered.");
			}
		}
		catch(InputMismatchException e)
		{
			System.out.print("Please enter valid marks.");
		}
	}
}