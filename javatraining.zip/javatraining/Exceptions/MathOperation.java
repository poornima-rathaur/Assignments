class MathOperation
{
	public static void main(String [] args)
	{
		int[] arr=new int[5];
		int sum=0;
		double average=0;
		try
		{
			for(int a=0;a<5;a++)
			{
				arr[a]=Integer.parseInt(args[a]);
			}
			for(int b:arr)
			{
				sum=sum+b;
			}
			System.out.println("Sum: "+sum);
			System.out.println("Average: "+(sum/5));
			
		}
		catch(ArithmeticException e)
		{
			System.out.println("Please enter a valid input");
		}
		catch(NumberFormatException e)
		{
			System.out.println("Please enter a valid input");
		}
	}
}