import java.util.Scanner;
public class ExcepetionAssignment1{
    public static void main(String[] arg)
    {
        int n;
        Scanner sc = new Scanner(System.in);
            System.out.println("Enter any valid Integer: ");
            try {
                n = sc.nextInt();
                System.out.println("You entered: "+ n*n);
                
            }
 
            catch (NumberFormatException e) {
                System.out.println("NumberFormatException occurred");
            }
        }
    }
