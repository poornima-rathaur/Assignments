import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
import java.io.BufferedInputStream;
class BufferedInputDemo
{
    public static void main(String[] args)
	{
	try
	{
	FileInputStream fin=new FileInputStream("poornima.txt");
	BufferedInputStream binput=new BufferedInputStream(fin);
	int i;
	while((i=binput.read())!=-1)
	{
	    System.out.print((char)i);
	}
	binput.close();
	fin.close();
	}
	catch(Exception e)
	{
	    e.printStackTrace();
		}
	}
}	
	