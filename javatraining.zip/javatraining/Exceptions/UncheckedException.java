class UncheckedException
{
	public static void main(String [] args)
	{
		try
		{
			System.out.println(100/0);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Cannot divide by zero");
			try
		    {
				Object ref = null;
				ref.toString();
		    }
			catch(NullPointerException f)
			{
				System.out.println("Object is null");
				try
				{
					int[] arr=new int[1];
					arr[5]=1;
				}
				catch(ArrayIndexOutOfBoundsException a)
				{
					System.out.println("Index out of Bound");
					try
					{
						Integer it=Integer.parseInt("null") ;
					}
					catch(NumberFormatException c)
					{
						System.out.println("NumberFormatException");
						try
						{
							String s="";
							s.charAt(3);
						}
						catch(StringIndexOutOfBoundsException sts)
						{
							System.out.println("String index out of bound");
						}
					}
				}
			}
		}
	}
}