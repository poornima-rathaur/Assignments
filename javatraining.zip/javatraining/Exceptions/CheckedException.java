import java.sql.*;
import java.io.*;

class CheckedException
{
	public static void main(String [] args)
	{
		try
		{
			FileReader file = new FileReader("C:/test/a.txt");
		}
		catch(FileNotFoundException f)
		{
			System.out.println("File Not found");
			try
			{
				Class.forName("heckedException");			
			}
			catch(ClassNotFoundException c)
			{
				System.out.println("Class Not found exception");
				try
				{
					Connection con=DriverManager.getConnection("Hello","Hello","Hello");
				}
				catch(SQLException s)
				{
					System.out.println("SQL exception");
				}
			}
		}
	}
}