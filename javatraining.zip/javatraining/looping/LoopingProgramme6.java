class LoopingProgramme6
{
 public static void main(String[] args)
 {
   double n=Double.parseDouble(args[0]);
  // double b=Double.parseDouble(args[0]);
  // double c=Double.parseDouble(args[0]);
   int flag=0;
   if (n == 0 || n == 1)
    flag = 1;

  for (int i = 2; i <= n / 2; ++i) {
    if (n % i == 0) {
      flag = 1;
      break;
   }
   }
   if (flag == 0)
    System.out.println("prime number");
  else
    System.out.println("not prime number");

}
}