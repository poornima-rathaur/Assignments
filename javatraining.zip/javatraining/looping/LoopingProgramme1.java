class LoopingProgramme1
{
 public static void main(String[] args)
 {
   double a=Double.parseDouble(args[0]);
  // double b=Double.parseDouble(args[0]);
  // double c=Double.parseDouble(args[0]);
   
  for(int i=1;i<=10;i++){
  System.out.println(i*a);
   }
   }
}